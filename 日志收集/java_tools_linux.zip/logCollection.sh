#!/bin/bash
BASE_PATH=$(readlink -m $0)
BASE_DIR=$(dirname $BASE_PATH)
BASE_NAME=$(basename $BASE_PATH .sh)

collection_dir=/tmp/${BASE_NAME}_$(date "+%Y%m%dT%H%M%S%z")
log=$collection_dir/${BASE_NAME}.log


function collect_I2000_log()
{
    echo "Begin to collect I2000 log info."
    mkdir $collection_dir/omu_log
    cp -R $OMU_HOME/run/log/ $collection_dir/omu_log/
    
}

function collect_Dmu_log()
{
    echo "Begin to collect Dmu log info."
    mkdir $collection_dir/dmu_log
    cp -R $DMU_HOME/log/ $collection_dir/dmu_log
}

function collect_Mq_log()
{
    echo "Begin to collect Mq log info."
    mkdir $collection_dir/mq_log
    cp -R $MQ_HOME/log/ $collection_dir/mq_log

}

function main()
{
    echo "If has the I2000 Node?[y/n]"
    read choose
    if [ $choose == "y" ];then
        echo "Collection the I2000 log info."
        mkdir -p $collection_dir
        chmod -R 777 $collection_dir
        
        collect_I2000_log
        collect_Dmu_log
        collect_Mq_log
    elif [ $choose == "n" ];then
        echo "Collection the Med log info."
        mkdir -p $collection_dir
        chmod -R 777 $collection_dir
        
        collect_Dmu_log
        collect_Mq_log
    else
        echo "Input error."
    fi
    
}

main