#!/bin/bash

BASE_PATH=$(readlink -m $0)
BASE_DIR=$(dirname $BASE_PATH)
BASE_NAME=$(basename $BASE_PATH .sh)

curTime=$(date "+%Y%m%dT%H%M%S%z")

collection_dir=/tmp/${BASE_NAME}-${curTime}
log=${collection_dir}/${BASE_NAME}-${curTime}.log

function print_error()
{
    [ -n "$@" ] && echo "[`date "+%F %T"`] ERROR: $@" | tee -a $log
}

function print_info()
{
    [ -n "$@" ] && echo "[`date "+%F %T"`] INFO: $@" | tee -a $log
}

function log_error()
{
    [ -n "$@" ] && echo "[`date "+%F %T"`] ERROR: $@" >>$log
}

function log_info()
{
    [ -n "$@" ] && echo "[`date "+%F %T"`] INFO: $@" >>$log
}

function die()
{
    print_error "$@"
    print_error "See log [$log] for details."
    exit 1
}

# java线程堆栈的本地线程显示为16进制，而top命令中的线程为10进制，为了方便比对，自动转换进制，并追加到尾部##
function change_jstack_nid()
{
    local jstack_file=$1
    for nid_str in $(grep -oE "nid=[0-9a-fx]*" $jstack_file)
    do
        nid16=$(echo $nid_str | awk -F= '{print $2}')
        ((nid10=$nid16))
        sed -i "s/$nid_str/nid=$nid16($nid10)/g" $jstack_file
    done
}

mkdir -p $collection_dir

# print_info "============================================================================================"
# print_info "sh $BASE_DIR/bin/jps.sh -mlv"
# print_info "============================================================================================"
# sh $BASE_DIR/bin/jps.sh -mlv | tee -a $log
# echo | tee -a $log
# echo | tee -a $log

print_info "============================================================================================"
print_info "ps -eww -o pid,user:20,cmd | grep -v grep | grep java"
print_info "============================================================================================"
# 显示java进程##
ps -eww -o pid,user:20,cmd | head -n1                                                    | tee -a $log
ps -eww -o pid,user:20,cmd | grep -v grep | grep java | grep -v tee | grep -v $BASE_NAME | tee -a $log
echo | tee -a $log
echo | tee -a $log

# 选择java进程##
read -p "Enter java PID: " pid
echo "You enter: $pid" | tee -a $log
[ -z "$pid" ] && echo "PID can not be empty." | tee -a $log && exit 1

#　检查输入的进程是否合法##
ps -eww -o pid,user:20,cmd | grep -v grep | grep java | awk '{print $1}' | grep -w $pid >/dev/null 2>&1
[ $? -ne 0 ] && echo "PID[$pid] is not a valid java progress." | tee -a $log && exit 1

# jdk提供的工具执行时必须保证当前操作系统用户和java进程用户一致，否则会报错。##
java_user=$(ps -eww -o pid,user:20,cmd | grep -v grep | grep java | grep -w $pid | awk '{print $2}')
cur_user=$(whoami)
if [ "$java_user" != "$cur_user" ]; then
    echo "Current os user[ $cur_user ] and java process user[ $java_user ] don't match." | tee -a $log
    echo "Please use the follow cmd [ su - $java_user -c \"sh $BASE_PATH\" ]" | tee -a $log
    exit 1
fi

echo | tee -a $log
echo | tee -a $log

# 根据进程id获得java路径##
export JAVA_CMD_FOR_TOOLS=$(readlink -m /proc/$pid/exe)

print_info "============================================================================================"
print_info "$JAVA_CMD_FOR_TOOLS -version"
print_info "============================================================================================"
$JAVA_CMD_FOR_TOOLS -version 2>&1 | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "sh $BASE_DIR/bin/jcmd.sh $pid VM.uptime"
print_info "============================================================================================"
sh $BASE_DIR/bin/jcmd.sh $pid VM.uptime | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "sh $BASE_DIR/bin/jcmd.sh $pid VM.system_properties"
print_info "============================================================================================"
sh $BASE_DIR/bin/jcmd.sh $pid VM.system_properties | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "sh $BASE_DIR/bin/jcmd.sh $pid VM.command_line"
print_info "============================================================================================"
sh $BASE_DIR/bin/jcmd.sh $pid VM.command_line | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "sh $BASE_DIR/bin/jstack.sh -l $pid"
print_info "gstack $pid"
print_info "top -bcH -n 1 -p $pid"
print_info "============================================================================================"
sh $BASE_DIR/bin/jstack.sh -l $pid | tee -a $collection_dir/jstack1.txt
gstack $pid                        | tee -a $collection_dir/pstack1.txt
top -bcH -n 1 -p $pid              | tee -a $collection_dir/top1.txt
change_jstack_nid                           $collection_dir/jstack1.txt
sleep 1s

sh $BASE_DIR/bin/jstack.sh -l $pid | tee -a $collection_dir/jstack2.txt
gstack $pid                        | tee -a $collection_dir/pstack2.txt
top -bcH -n 1 -p $pid              | tee -a $collection_dir/top2.txt
change_jstack_nid                           $collection_dir/jstack2.txt
sleep 1s

sh $BASE_DIR/bin/jstack.sh -l $pid | tee -a $collection_dir/jstack3.txt
gstack $pid                        | tee -a $collection_dir/pstack3.txt
top -bcH -n 1 -p $pid              | tee -a $collection_dir/top3.txt
change_jstack_nid                           $collection_dir/jstack3.txt
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "sh $BASE_DIR/bin/jmap.sh -histo $pid"
print_info "============================================================================================"
sh $BASE_DIR/bin/jmap.sh -histo $pid | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "sh $BASE_DIR/bin/jmap.sh -histo:live $pid"
print_info "============================================================================================"
sh $BASE_DIR/bin/jmap.sh -histo:live $pid | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "pmap $pid"
print_info "============================================================================================"
# 进程的地址空间和内存状态信息##
pmap $pid | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "sh $BASE_DIR/bin/jmap.sh -dump:format=b,file=$collection_dir/heap_dump.hprof $pid"
print_info "============================================================================================"
sh $BASE_DIR/bin/jmap.sh -dump:format=b,file=$collection_dir/heap_dump.hprof $pid | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "sh $BASE_DIR/bin/jstat.sh -gc $pid 1000 10"
print_info "============================================================================================"
sh $BASE_DIR/bin/jstat.sh -gc $pid 1000 10 | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "sh $BASE_DIR/bin/jstat.sh -gccause $pid 1000 10"
print_info "============================================================================================"
sh $BASE_DIR/bin/jstat.sh -gccause $pid 1000 10 | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "$JAVA_CMD_FOR_TOOLS -Djava.library.path=$BASE_DIR/lib -classpath $BASE_DIR/lib/tools.jar:$BASE_DIR/bin/jtop.jar jtop -size H -thread 5 -stack 100 --color $pid 1000 10"
print_info "============================================================================================"
# 显示java进程中cpu最高的top5线程，间隔2秒，打印10次##
$JAVA_CMD_FOR_TOOLS -Djava.library.path=$BASE_DIR/lib -classpath $BASE_DIR/lib/tools.jar:$BASE_DIR/bin/jtop.jar jtop -size H -thread 5 -stack 100 --color $pid 1000 10 | tee -a $log
echo | tee -a $log
echo | tee -a $log

print_info "============================================================================================"
print_info "zip -r $collection_dir.zip $collection_dir"
print_info "============================================================================================"
zip -r $collection_dir.zip $collection_dir
echo
echo

print_info "============================================================================================"
print_info "du -ah $collection_dir* | sort -r -k 2"
print_info "============================================================================================"
du -ah $collection_dir* | sort -r -k 2
echo
echo

echo "The target file is [ $collection_dir.zip ]."
echo
echo

