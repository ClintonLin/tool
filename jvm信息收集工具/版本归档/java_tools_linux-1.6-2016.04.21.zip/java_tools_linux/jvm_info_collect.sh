#!/bin/bash

BASE_PATH=$(readlink -m $0)
BASE_DIR=$(dirname $BASE_PATH)
BASE_NAME=$(basename $BASE_PATH .sh)

collection_dir=/tmp/${BASE_NAME}_$(hostname)_$(date "+%Y%m%dT%H%M%S%z")
log=$collection_dir/${BASE_NAME}.log

function print_error()
{
    [ -n "$@" ] && echo "[`date "+%F %T"`] ERROR: $@" | tee -a $log
}

function print_info()
{
    [ -n "$@" ] && echo "[`date "+%F %T"`] INFO: $@" | tee -a $log
}

function log_error()
{
    [ -n "$@" ] && echo "[`date "+%F %T"`] ERROR: $@" >>$log
}

function log_info()
{
    [ -n "$@" ] && echo "[`date "+%F %T"`] INFO: $@" >>$log
}

function die()
{
    print_error "$@"
    print_error "See log [$log] for details."
    exit 1
}

find $BASE_DIR -name "*.sh" | xargs dos2unix >/dev/null 2>&1
find $BASE_DIR -name "*.sh" | xargs chmod +x >/dev/null 2>&1

mkdir -p $collection_dir
chmod -R 777 $collection_dir

# print_info "============================================================================================"
# print_info "sh $BASE_DIR/bin/jps.sh -mlv"
# print_info "============================================================================================"
# sh $BASE_DIR/bin/jps.sh -mlv | tee -a $log
# echo | tee -a $log
# echo | tee -a $log

print_info "============================================================================================"
print_info "ps -eww -o pid,user:20,cmd | grep -v grep | grep java"
print_info "============================================================================================"
# 显示java进程##
ps -eww -o pid,user:20,cmd | head -n1                                                    | tee -a $log
ps -eww -o pid,user:20,cmd | grep -v grep | grep java | grep -v tee | grep -v $BASE_NAME | tee -a $log
echo | tee -a $log
echo | tee -a $log

# 选择java进程##
read -p "Enter java PID: " pid
echo "You enter: $pid" | tee -a $log
[ -z "$pid" ] && echo "PID can not be empty." | tee -a $log && exit 1

# 检查输入的进程是否合法##
ps -eww -o pid,user:20,cmd | grep -v grep | grep java | awk '{print $1}' | grep -w $pid >/dev/null 2>&1
[ $? -ne 0 ] && echo "PID[$pid] is not a valid java progress." | tee -a $log && exit 1

# jdk提供的工具执行时必须保证当前操作系统用户和java进程用户一致，否则会报错。##
java_user=$(ps -eww -o pid,user:20,cmd | grep -v grep | grep java | grep -w $pid | awk '{print $2}')
cur_user=$(whoami)
if [ "$java_user" != "$cur_user" ]; then
    echo "Current os user[ $cur_user ] and java process user[ $java_user ] don't match." | tee -a $log
    echo "Now switch the user to [ $java_user ]." | tee -a $log
    su - $java_user -c "sh $BASE_DIR/bin/jvm_info_collect_inner.sh $pid $collection_dir" | tee -a $log
else
    sh $BASE_DIR/bin/jvm_info_collect_inner.sh $pid $collection_dir | tee -a $log
fi

echo | tee -a $log
echo | tee -a $log

