#!/bin/bash

count=$1
interval=$2
i2000RootPath=$3
currPath="`pwd`"
outputPath="$currPath/output"

if [ ! -d $outputPath ]; then
	mkdir $outputPath
fi

if [ -z "${count}" ]; then
	count=1
fi

if [ -z "${interval}" ]; then
	interval=1
fi

if [ -z "${i2000RootPath}" ]; then
	i2000RootPath="$I2000_HOME/I2000/run"
fi

logPath="$i2000RootPath/var/iemp/log"

index=1
while [ 1 -eq 1 ]
do
	tailf $logPath/stack.log > "$outputPath/stack_$index.txt"&
	ps -ef | grep '/run/jre/bin/java -Dprocname=I2000 ' | grep -v grep | awk '{print $2}'| xargs kill -3;top -Hp `ps -ef | grep '/run/jre/bin/java -Dprocname=I2000 ' | grep -v grep | awk '{print $2}'` -b -n 1 | head -n 500 > "$outputPath/topThread_$index.txt";
	ps -ef|grep "tailf $logPath/stack.log" | grep -v grep |  awk '{print $2}'| xargs kill -9  > /dev/null 2>&1
	echo "Finish to dump stack info: $index"
	index=`expr $index + 1`
	if [ $index -gt $count ]; then
		break;
	fi
	sleep $interval
done

echo "Finish to dump all stack info, start to parse stack info"

index=1
while [ 1 -eq 1 ]
do
	$i2000RootPath/jre/bin/java -classpath stack.jar StackParser "$outputPath/topThread_$index.txt" "$outputPath/stack_$index.txt" "$outputPath/result_$index.txt" "`whoami`"
	echo "Finish to parse stack info: $index"
	index=`expr $index + 1`
	if [ $index -gt $count ]; then
		exit 0
	fi
done
