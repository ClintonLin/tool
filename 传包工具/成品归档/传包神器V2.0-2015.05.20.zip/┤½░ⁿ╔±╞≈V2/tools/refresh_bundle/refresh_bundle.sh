#!/bin/bash

# check args num
if [ $# != 2 ] ; then
    echo "USAGE: $0 telnet_ports jar_names_file"
    exit 1;
fi

base_dir=$(cd $(dirname $0); pwd)

# resovle agrs
telnet_ports=$1
jar_names_file=$2

# check osgi ports is avail.
for telnet_port in $telnet_ports
do
    line_num=`netstat -anp | grep -c -w $telnet_port`
    if [ "X0" = "X$line_num" ]; then
        echo "ERROR: Telnet_port [$telnet_port] is not available.";
        exit 1;
    fi
done

# backup not ACTIVE bundles.
echo "----------------------------------------------------------------------"
echo "Backup not ACTIVE bundles."
echo "----------------------------------------------------------------------"
for telnet_port in $telnet_ports
do
    (echo "ss" ; sleep 0.2s) | telnet 127.0.0.1 $telnet_port | grep "^[0-9]" | grep -v "ACTIVE" > $base_dir/osgi_${telnet_port}_before
done
echo ""

dos2unix $base_dir/$jar_names_file >/dev/null 2>&1

# update and refresh bundles.
for telnet_port in $telnet_ports
do
    echo "----------------------------------------------------------------------"
    echo "Refresh osgi[127.0.0.1 $telnet_port] bundles."
    echo "----------------------------------------------------------------------"

    while read -r line
    do
        jarName=$line
        bundleName=`echo ${jarName%-*-*}`
        bundleId=`(echo "ss" ; sleep 0.2s) | telnet 127.0.0.1 $telnet_port | grep "$bundleName" | awk -F' ' '{print $1}'`
        if [ -z $bundleId ] ; then
            continue
        fi

        (echo "update $bundleId" ; sleep 0.2s) | telnet 127.0.0.1 $telnet_port >/dev/null 2>&1
        (echo "refresh $bundleId" ; sleep 0.2s) | telnet 127.0.0.1 $telnet_port >/dev/null 2>&1
        echo "Refresh bundle[id=$bundleId,name=$bundleName] success."
    done < $base_dir/$jar_names_file
    echo ""
done
echo ""

# compare not ACTIVE bundles.
for telnet_port in $telnet_ports
do
    echo "----------------------------------------------------------------------"
    echo "Check osgi[127.0.0.1 $telnet_port] bundles state."
    echo "----------------------------------------------------------------------"

    bundleState=NOK
    for i in {1..10}
    do
       (echo "ss" ; sleep 0.2s) | telnet 127.0.0.1 $telnet_port | grep "^[0-9]" | grep -v "ACTIVE" > $base_dir/osgi_${telnet_port}_after
       diff $base_dir/osgi_${telnet_port}_before $base_dir/osgi_${telnet_port}_after >/dev/null 2>&1
       if [ $? -eq 0 ] ; then
           bundleState=OK
           break
       fi
       sleep 5s
    done

    echo "Before refresh [127.0.0.1 $telnet_port] bundles state:"
    cat $base_dir/osgi_${telnet_port}_before
    echo ""

    echo "After  refresh [127.0.0.1 $telnet_port] bundles state:"
    cat $base_dir/osgi_${telnet_port}_after
    echo ""

    if [ "XOK" = "X$bundleState" ] ; then
        echo "NO different. Refresh [127.0.0.1 $telnet_port] success."
    else
        echo "Have different. Refresh [127.0.0.1 $telnet_port] failed. Please restart virgo youself."
    fi

    echo ""
done

