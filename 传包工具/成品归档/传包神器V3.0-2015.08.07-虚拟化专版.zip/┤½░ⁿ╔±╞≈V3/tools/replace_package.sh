#!/bin/bash

SH_PATH=$(readlink -m $0)
SH_DIR=$(dirname ${SH_PATH})
SH_NAME=$(basename ${SH_PATH} .sh)

log=$SH_DIR/$SH_NAME.log

function write_log()
{
	[ -n "$@" ] && echo "[`date "+%F %T"`] $@" >>$log
}

function print_log()
{
	[ -n "$@" ] && echo "$@"
	[ -n "$@" ] && echo "[`date "+%F %T"`] $@" >>$log
}

function die()
{
	print_log "$@"
	print_log "See log [$log]"
	exit 1
}

[ $# -eq 0 ] && echo "Usage: sh $0 <path...>" && exit 1
search_path="$@"
# search_path="${OMU_HOME}/run ${DMU_HOME}/repository"

# 旧包目录存在且不为空，备份此目录
[ -d "$SH_DIR/old" ] && [ -n "$(ls -A $SH_DIR/old)" ] && mv $SH_DIR/old $SH_DIR/old_`date +%Y%m%d%H%M%S`

mkdir -p $SH_DIR/new
mkdir -p $SH_DIR/old

>$SH_DIR/new_jar_path.txt
>$SH_DIR/new_war_path.txt
>$SH_DIR/old_jar_path.txt
>$SH_DIR/old_war_packed_path.txt
>$SH_DIR/old_war_unpacked_path.txt

find $SH_DIR/new -type f -iname "*.jar" >$SH_DIR/new_jar_path.txt
find $SH_DIR/new -type f -iname "*.war" >$SH_DIR/new_war_path.txt

# 处理jar包
while read new_jar_path
do
	new_jar_name=$(basename $new_jar_path)
	find_jar_para="$find_jar_para -o -type f -iname $new_jar_name"
done <$SH_DIR/new_jar_path.txt

if [ -n "$find_jar_para" ]; then
	find_jar_cmd="find $search_path ${find_jar_para#*-o}"
	`$find_jar_cmd >$SH_DIR/old_jar_path.txt`

	# 替换jar包
	while read new_jar_path
	do
		new_jar_name=$(basename $new_jar_path)
		echo "-----------------------------------------------------------------------"
		echo "Handling $new_jar_name"
		echo "-----------------------------------------------------------------------"
		while read old_jar_path
		do
			old_jar_name=$(basename $old_jar_path)
			if [ "$old_jar_name" = "$new_jar_name" ]; then
				echo "replace to: $old_jar_path"
				cp $old_jar_path $SH_DIR/old/$new_jar_name
				cp $new_jar_path $old_jar_path
			fi
		done <$SH_DIR/old_jar_path.txt
		echo
	done <$SH_DIR/new_jar_path.txt
fi

# 处理war包
while read new_war_path
do
	new_war_name=$(basename $new_war_path)
	find_war_packed_para="$find_war_packed_para -o -type f -iname $new_war_name"
	find_war_unpacked_para="$find_war_unpacked_para -o -type d -iname ${new_war_name%.*}"
done <${SH_DIR}/new_war_path.txt

if [ -n "$find_war_packed_para" -a -n "$find_war_unpacked_para" ]; then
	find_war_packed_cmd="find $search_path ${find_war_packed_para#*-o}"
	`$find_war_packed_cmd >$SH_DIR/old_war_packed_path.txt`

	find_war_unpacked_cmd="find $search_path ${find_war_unpacked_para#*-o}"
	`$find_war_unpacked_cmd >$SH_DIR/old_war_unpacked_path.txt`

	while read new_war_path
	do
		new_war_name=$(basename $new_war_path)
		echo "-----------------------------------------------------------------------"
		echo "Handling $new_war_name"
		echo "-----------------------------------------------------------------------"

		# 替换压缩的war包
		while read old_war_packed_path
		do
			old_war_packed_name=$(basename $old_war_packed_path)
			if [ "$old_war_packed_name" = "$new_war_name" ]; then
				echo "replace to: $old_war_packed_path"
				cp $old_war_packed_path $SH_DIR/old/$new_war_name
				cp $new_war_path $old_war_packed_path
			fi
		done <$SH_DIR/old_war_packed_path.txt

		# 替换解压缩的war包
		while read old_war_unpacked_path
		do
			old_war_unpacked_name=$(basename $old_war_unpacked_path)
			if [ "$old_war_unpacked_name" = "${new_war_name%.*}" ]; then
				echo "replace to: ${old_war_unpacked_path}"
				user=`ls -l -d $old_war_unpacked_path | awk '{print $3}'`
				group=`ls -l -d $old_war_unpacked_path | awk '{print $4}'`

				`cd $old_war_unpacked_path && zip -qr $SH_DIR/old/$new_war_name ./ && rm -rf $old_war_unpacked_path`
				unzip -qo $new_war_path -d $old_war_unpacked_path
				chmod -R 770 $old_war_unpacked_path
				chown -R $user:$group $old_war_unpacked_path
			fi
		done <$SH_DIR/old_war_unpacked_path.txt
		echo
	done <$SH_DIR/new_war_path.txt
fi

